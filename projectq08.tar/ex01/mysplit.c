#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void append(char* s, char c) {
        int len = strlen(s);
        s[len] = c;
        s[len+1] = '\0';
}

  typedef struct s_string_array {
    int size;
    char** array;
  } string_array;


//strstr that returns the left side of divider.
char* my_strstr(char* a, char *b) {
  int lena;
  lena = strlen(a);
  int lenb;
  lenb = strlen(b);
  int d;
  int i = 0, j = 0;
  char* c;
  c = (char*)malloc(100*sizeof(char));
    if (*(b)=='\0'){
        return a;
    }
    while ((*(a + j) != '\0')&&(*(b + i) != '\0')) {
        if (*(b + i) != *(a + j)) {
            j++;
            i = 0;
        }
        else {   
            if (b[lenb-1] == a[j-i+lenb-1]) {
                i++;
                
                }
                j++;
                d=j-i;
        }
    }
    if (*(b + i) == '\0'){
        for(int k=0;k<d;k++){
            c[k]=a[k];
        }
        c[d]='\0';
        return c;}
    else{
        return 0;
    }
}
string_array* my_split(char* param_1, char* param_2) {
    string_array* ans;
    ans = (string_array*)malloc(2*sizeof(string_array));
    ans->array = (char**)malloc(100*sizeof(char));
    int size=0;
    int d;
    //need to find size first


    for (int i=0;i<=size;i++){
        strcpy(ans->array[i],my_strstr(param_1,param_2));
        if(strcmp(ans->array[i],my_strstr("abc", "d"))==0){
            strcpy(ans->array[i],param_1);
            size++;
            break;
        }
        //shorten param1
        d = strlen(param_1) - strlen(ans->array[i]);
        for (int j=0;j<d-strlen(param_2);j++){
            param_1[j]=param_1[j+strlen(param_2)+strlen(ans->array[i])];
        }
        param_1[d-strlen(param_2)]='\0';
        //increase size
        size++;
    }

    ans->size=size;
    return ans;
}
int main(){
    char* a = "abc def gh-!";
    char* b = " ";
    
    printf("%s", *(my_split(a, b))->array);
}