#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>
// typedef struct s_string_array {
//     int size;
//     char** array;
//   } string_array;

char** str_split(char* a_str, char* a_delim)
{

    char** result    = 0;
    size_t count     = 0;
    char* tmp        = a_str;
    char* last_comma = 0;
    char* delim[2];
    delim[0] = a_delim;
    delim[1] = 0;

    /* Count how many elements will be extracted. */
    while (*tmp)
    {
        if (a_delim == tmp)
        {
            count++;
            last_comma = tmp;
        }
        tmp++;
    }

    /* Add space for trailing token. */
    count += last_comma < (a_str + strlen(a_str) - 1);

    /* Add space for terminating null string so caller
       knows where the list of returned strings ends. */
    count++;

    result = malloc(sizeof(char*) * count);

    if (result)
    {
        size_t idx  = 0;
        char* token = strtok(a_str, a_delim);

        while (token)
        {
            assert(idx < count);
            *(result + idx++) = strdup(token);
            token = strtok(0, a_delim);
        }
        assert(idx == count - 1);
        *(result + idx) = 0;
    }
    // string_array* ans;
    // ans = (string_array*)malloc(2*sizeof(string_array));
    // ans->size = count;
    return result;
}

string_array* my_split(char* param_1, char* param_2) {
    string_array* ans;
    ans = (string_array*)malloc(2*sizeof(string_array));
    ans->array = (char**)malloc(100*sizeof(char));
    // ans->array = str_split(param_1, param_2);

    // if (ans->array)
    // {
    //     int i;
    //     for (i = 0; *(ans->array + i); i++)
    //     {
    //         printf("month=[%s]\n", *(ans->array + i));
    //         free(*(ans->array + i));
    //     }
    //     printf("\n");
    //     free(ans->array);
    // }


    
    
    char *token;
    char *rest = NULL;

    int size=0;
    int i=0;

    for (token = strtok_r(param_1, param_2, &rest);
         token != NULL;
         token = strtok_r(NULL, param_2, &rest)) {   
        ans->array[i]= strdup(token);
        i++;
    }
    ans->size=i;
    return ans;

}