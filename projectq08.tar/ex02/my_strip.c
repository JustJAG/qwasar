#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void append(char* s, char c) {
        int len = strlen(s);
        s[len] = c;
        s[len+1] = '\0';
}

char* my_strip(char* param_1) {
    char* ans;
    ans = (char*)malloc(100*sizeof(char));

    //find first symbol that not space
    int start=0,end=strlen(param_1);
    for( int i=0;i<strlen(param_1);i++){
        if (param_1[i]/1==32){
            start=i+1;
        } else {
            break;
        }
    }
    //find last symbol that not space
    for( int i=strlen(param_1)-1;i>0;i--){
        if (param_1[i]/1==32){
            end=i-1;
        } else {
            break;
        }
    }
    //make param_1
    for( int i=0;i<end-start+1;i++){
        param_1[i]=param_1[i+start];
    }
    param_1[end-start+1]='\0';
    //get rid of extra spaces
    for (int i=0;i<strlen(param_1);i++){
        if (param_1[i]/1==32){
            if(param_1[i+1]/1!=32){
                append(ans,param_1[i]);
            }
        } else{
            append(ans,param_1[i]);
        }
    }
    return ans;
}
// int main(){
//     char* param = " this        time it      will     be    more complex  . ";
//     printf("%s", my_strip(param));
//     return 0;
// }