#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void append(char* s, char c) {
        int len = strlen(s);
        s[len] = c;
        s[len+1] = '\0';
}

char* my_union(char* a, char* b) {
  int i,j=0,k=0;
  char* uni;
  uni = (char*)malloc(sizeof(char*));

  //add b to a to make 1 string
  int lena = strlen(a);
  for (i=0;i<strlen(b);i++){
      a[lena+i]=b[i];
  }
  a[strlen(a)+1]='\0';
  append(uni, a[0]);
  //printf("%s", a);
  for (i=1;i<strlen(a);i++){
      for(j=0;j<strlen(uni);j++){
          if(a[i]==uni[j]){
              k++;
          }
      }
          if(k==0){
              append(uni, a[i]);
          }
          k=0;
      
  }
  
  return uni;
}
// int main(){
//     char* a = (char*)malloc(sizeof(char*));
//     a = "zpadinton";
//     char* b = (char*)malloc(sizeof(char*));
//     b = "paqedova";
//     my_union(a, b);
//     return 0;
// }