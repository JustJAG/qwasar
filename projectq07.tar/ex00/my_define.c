#include <stdio.h>

#define ISEVEN(n)    ((n%2 == 0) ? 1 : 0)
#define ISODD(n)    ((n%2 != 0) ? 1 : 0)

char* my_define(int a) {
    char* res;
    if(ISEVEN(a)){
        res = "I have an even number of arguments.";
    }else if(ISODD(a)){
        res = "I have an odd number of arguments.";
    }
    return res;
}