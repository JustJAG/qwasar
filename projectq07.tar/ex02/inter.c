#include <stdio.h>
#include <string.h>
#include <stdlib.h>
void append(char* s, char c) {
        int len = strlen(s);
        s[len] = c;
        s[len+1] = '\0';
}

char* inter(char* a, char* b) {
  int i,j=0,k=0,l=0;
  char* uni;
  uni = (char*)malloc(sizeof(char*));
  char* c;
  c = (char*)malloc(sizeof(char*));
  //add b to a to make 1 string
  int lena = strlen(a);
  for (i=0;i<strlen(a);i++){
      c[i]=a[i];
  }
  for (i=0;i<strlen(b);i++){
      c[i+lena]=b[i];
  }
  //a[strlen(a)+1]='\0';
//   append(uni, a[0]);
  //printf("%s", a);
  for (i=0;i<strlen(a);i++){
      for(j=0;j<strlen(uni);j++){
          if(a[i]==uni[j]){
              k++;
          }
      }
      for (j=0;j<strlen(b);j++){
          if(a[i]==b[j]){
              l++;
          }
      }
          if(k==0){
              if(l!=0){
                  append(uni, a[i]);
              }
          }
          k=0;
          l=0;
      
  }
  
  return uni;
}
// int main(){
//     char* a = (char*)malloc(sizeof(char*));
//     a = "zpadinton";
//     char* b = (char*)malloc(sizeof(char*));
//     b = "paqedova";
//     my_union(a, b);
//     return 0;
// }